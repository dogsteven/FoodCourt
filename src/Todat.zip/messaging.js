import firebase from './firebase'

let messaging = firebase.messaging()

export default messaging